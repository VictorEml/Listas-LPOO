public class Aniversario extends CartaoWeb {
    
    public Aniversario() {
        super ();
    }
    
    public void retonarMensagem (){
        System.out.println("Querida " +this.getDestinatario());
        System.out.println("Feliz Aniversário!!!");
        System.out.println("Só passei para te desejar um dia repleto de alegria, e que essa data se repita por muitos anos!");
        System.out.println("Atenciosamente, seu amor!" +this.getRemetente());
    }
}
