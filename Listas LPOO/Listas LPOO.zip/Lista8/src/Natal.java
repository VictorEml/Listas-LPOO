public class Natal extends CartaoWeb {

    public Natal() {
        super ();
    }
    
    public void retornarMensagem (){
        System.out.println("Querida "+this.destinatario+",");
        System.out.println("Feliz Natal!");
        System.out.println("A te desejo tudo de bom nesse mundo, que seu natal seja repleto e alegria e paz.");
        System.out.println("Atenciosamente, seu amor " +this.remetente);
    }
    
}

