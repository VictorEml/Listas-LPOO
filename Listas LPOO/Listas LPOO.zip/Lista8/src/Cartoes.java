
import javax.swing.JOptionPane;

public class Cartoes {

    public static void main(String[] args) {

        int[] cartaoweb = new int[3];
        int car;
        //car = cartoes

        CartaoWeb c = new CartaoWeb() {
        };
        DiaDosNamorados d = new DiaDosNamorados();
        Aniversario a = new Aniversario();
        Natal n = new Natal();

        c.destinatario = JOptionPane.showInputDialog("Informe o nome do Destinatário ");
        c.remetente = JOptionPane.showInputDialog("Informe o nome do remetente ");

        for (car = 0; car <= 3; car++) {
            if (car == 1) {
                d.retornarMensagem();
            }
            if (car == 2) {
                a.retonarMensagem();
            }
            if (car == 3) {
                n.retornarMensagem();
            }
        }
    }

}
