public class DiaDosNamorados extends CartaoWeb {

    public DiaDosNamorados() {
        super ();
    }
    public void retornarMensagem (){
        System.out.println("Querida " + this.destinatario + ",");
        System.out.println("Feliz Dia dos Namorados!");
        System.out.println("Espero que esse tenha sido o único cartão do dia dos namorados que tenha ganhado nessa data!");
        System.out.println("De todo meu coração, " +this.remetente);
    }   
}
