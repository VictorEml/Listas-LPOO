
public class Fornecedor extends Pessoa {

    int creditoMaximo;
    int valorEmDivida;
    int credito;

    public Fornecedor() {
        super();
        this.creditoMaximo = creditoMaximo;
        this.valorEmDivida = valorEmDivida;
    }

    public int obterSaldo() {
        credito = creditoMaximo - valorEmDivida;
        return credito;
    }

}
