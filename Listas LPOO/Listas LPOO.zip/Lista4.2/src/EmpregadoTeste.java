
import javax.swing.JOptionPane;

public class EmpregadoTeste {

    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        Empregado e = new Empregado();

        p.nome = JOptionPane.showInputDialog("Informe o nome: ");
        p.idade = JOptionPane.showInputDialog("Informe a idade: ");
        p.altura = JOptionPane.showInputDialog("Informe a altura: ");
        p.sexo = JOptionPane.showInputDialog("Informe o sexo: ");
        e.salario = JOptionPane.showInputDialog("Informe o salario: ");

        JOptionPane.showMessageDialog(null, "Nome: " + p.nome);
        JOptionPane.showMessageDialog(null, "Idade: " + p.idade);
        JOptionPane.showMessageDialog(null, "Altura: " + p.altura);
        JOptionPane.showMessageDialog(null, "Sexo: " + p.sexo);
        JOptionPane.showMessageDialog(null, "Salario: " + e.salario);
    }

}
