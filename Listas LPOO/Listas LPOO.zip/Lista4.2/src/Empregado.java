
public class Empregado extends Pessoa {

    String salario;

    public Empregado() {
        super();
        this.salario = salario;
    }

    public String obterLucros() {
        return salario;
    }

    public String getSalario() {
        return salario;
    }

    public void setSalario(String salario) {
        this.salario = salario;
    }
   
}
