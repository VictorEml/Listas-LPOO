
public class Administrador extends Empregado {

    int ajudaDeCurso;

    public Administrador(int ajudaDeCurso) {
        super();
        this.ajudaDeCurso = ajudaDeCurso;
    }  
}