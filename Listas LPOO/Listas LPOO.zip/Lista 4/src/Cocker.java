
public class Cocker extends Cachorro {

    boolean tosa;

    public Cocker() {
        this.tosa = tosa;
        precisaTosa();
    }

    public boolean precisaTosa() {
        return tosa;
    }

    public void setTosa(boolean tosa) {
        this.tosa = tosa;
    }
}
