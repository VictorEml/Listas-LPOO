
import javax.swing.JOptionPane;

public class CockerTeste {

    public static void main(String[] args) {
        Animal a = new Animal();
        Cachorro c = new Cachorro();
        Cocker coc = new Cocker();
        int alter;

        a.tipo = JOptionPane.showInputDialog("Informe o tipo?");
        a.cor = JOptionPane.showInputDialog("Informe a cor?");
        c.nome = JOptionPane.showInputDialog("Informe o nome?");
        c.raca = JOptionPane.showInputDialog("Informe a raça?");

        alter = Integer.parseInt(JOptionPane.showInputDialog("1- Não precisa de tosa 2- Precisa de tosa"));
        if (alter == 1) {
            coc.tosa = false;
        }
        if (alter == 2) {

            coc.tosa = true;
        }

        JOptionPane.showMessageDialog(null, "Cor " + a.cor);
        JOptionPane.showMessageDialog(null, "Tipo: " + a.tipo);
        JOptionPane.showMessageDialog(null, "Nome: " + c.nome);
        JOptionPane.showMessageDialog(null, "Raça: " + c.raca);
    }
}
